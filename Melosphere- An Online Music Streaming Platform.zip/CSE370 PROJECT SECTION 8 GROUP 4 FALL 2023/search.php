<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css" />
    <link rel="stylesheet" href="searchbar.css" />

    <style>

    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1 class="center"><a href="index.php">MusicProject</a></h1>
            <nav>
                <ul>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="main-content">
        <h2>Welcome to MusicProject</h2>
        <p class="main-head">Explore. Listen. Enjoy. MusicProject – Where the World Finds Its Rhythm, for Free!</p>

        <form action="search_backend.php" method="post" class="floating-search-bar">
            <input type="text" name="search" class="search-input" placeholder="Search songs...">
            <button type="submit" class="search-button">Search</button>
        </form>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 MusicProject. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>





