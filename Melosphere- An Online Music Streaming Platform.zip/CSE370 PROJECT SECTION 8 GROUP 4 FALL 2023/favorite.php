<?php
session_start();
require_once("DBconnect.php");
$user_id=$_SESSION["user_id"];
$fav_songs = "SELECT favorite.song_id,song_name, genre,album_name,artist_name,song_link,no_of_plays from song INNER JOIN favorite on song.song_id = favorite.song_id WHERE user_id = '$user_id'";
$result = mysqli_query($conn,$fav_songs);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>"/>
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="authenticated.php">Melosphere</a></h1>
        <nav>
          <ul>
            <li><a href="song.php">Songs</a></li>
            <li><a href="playlist.php">My Playlist</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
            

          </ul>
        </nav>
      </div>
    </header>

    <section class="main-content">
      <p class="main-head">Your Favorite Songs</p>
    </section>

    <div>
      <table class="table">
        <tr>
          <th id='play'>Play</th>
          <th id="song">Song</th>
          <th id="genre">Genre</th>
          <th id="Album">Album</th>
          <th id="Artist">Artist</th>
          <th id="No-of-plays">Number of Times Played</th>
        </tr>
      
      <?php

        while($row = mysqli_fetch_assoc($result)){
      ?>
      <tr>
          <td class="play">
          <form action="increment-play.php" method="post">
            <button type="submit" name="play" value="<?php echo htmlspecialchars($row["song_id"])?>">Play</button>
          </form>
          </td>
          <td>
            <?php echo $row["song_name"]?>
          </td>
          <td><?php echo $row["genre"]?></td>
          <td><?php echo $row["album_name"]?></td>
          <td><?php echo $row["artist_name"]?></td>
          <td><?php echo $row["no_of_plays"]?></td>
      </tr>

      <?php
      
        }         
      ?>


      </table>
    </div>  
    <footer>
      <div class="container">
        <p>&copy; 2023 MusicProject. All rights reserved.</p>
      </div> 
    </footer>
  </body>
</html>

