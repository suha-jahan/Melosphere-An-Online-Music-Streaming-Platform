<?php

include "DBConnect.php";
$search = isset($_POST['search']) ? $_POST['search'] : '';

if (!empty($search)) {

    $query = $conn->prepare("SELECT * FROM song WHERE song_name = ?");
    $query->bind_param("s", $search);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {

        $songDetails = $result->fetch_assoc();
        $songName = $songDetails['song_name'];
        $query->close();
        $result->close();

        header("Location: success_page.php?song_name=" . urlencode($songName));
        exit();
    } else {
        echo "Error, try again!";
    }

    $result->close();

    $query->close();
} else {
    echo "Search term not provided.";
}

$conn->close();
?>






