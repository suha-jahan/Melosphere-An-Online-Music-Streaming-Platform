<!DOCTYPE html>
<?php session_start();?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="adminView.php">Melosphere</a></h1>
        <nav>
          <ul>
            <li><a href="song-admin.php">Songs</a></li>
            <li><a href="addsongform.php">Add Songs</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <section class="main-content">
      <h2>Welcome Admin!</h2>
      <p class="main-head">What would you like to remove or add today?</p>
    </section>
    <footer>
      <div class="container">
      </div> 
    </footer>
  </body>
</html>
