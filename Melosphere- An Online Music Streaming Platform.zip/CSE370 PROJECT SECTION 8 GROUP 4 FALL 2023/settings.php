<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Settings</title>
  <link rel="stylesheet" href="register.css">
</head>
<body>
	
		<div class="register-container">
			<section class="main-content">
				<h1>Settings</h1>
				  <!---<nav>  </nav>--->
					<ol>
						<li><a href="change-name.php">Change Name</a></li><br>
						<li><a href="change-password.php">Change Password</a></li><br>
						<li><a href="delete-account.php">Delete Account</a></li>
					</ol>	
	        </section>
		</div>	
</body>
</html>


