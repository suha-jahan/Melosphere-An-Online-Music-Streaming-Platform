<?php
session_start();
require_once("DBconnect.php");
if ($_SERVER["REQUEST_METHOD"] === "POST"){
if(isset($_POST['album-song'])){
$album_name = htmlspecialchars($_POST['album-song']);
$all_album_songs = "SELECT album_song FROM track_of_album WHERE album_name = '$album_name'";
$result = mysqli_query($conn,$all_album_songs);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>"/>
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="authenticated.php">Melosphere</a></h1>
        <nav>
          <ul>
            <li><a href="song.php">Songs</a></li>
            <li><a href="playlist.php">My Playlist</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
            

          </ul>
        </nav>
      </div>
    </header>

    <section class="main-content">
      <h2> <?php echo  htmlspecialchars($album_name) ?></h2>
    </section>

    <div>
      <table class="table">
        <tr>
          <th id="album-song">Song</th>
      
      <?php

        while($row = mysqli_fetch_assoc($result)){
      ?>
      <tr>
          
          <td><?php echo htmlspecialchars($row["album_song"])?></td>
          
      </tr>

      <?php
      
        }         
      ?>

<?php } ?>
<?php }?>
      </table>
    </div>  
    <footer>
      <div class="container">
        <p>&copy; 2023 MusicProject. All rights reserved.</p>
      </div> 
    </footer>
  </body>
</html>

