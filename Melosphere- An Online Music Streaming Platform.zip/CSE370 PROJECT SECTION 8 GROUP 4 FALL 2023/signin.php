<?php
session_start();
require_once('DBconnect.php');
if ($_SERVER["REQUEST_METHOD"] === "POST"){
    if(isset($_POST['username']) && isset($_POST['password'])){

        $username = $_POST['username'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM user WHERE user_name='$username' AND password = '$password'";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) !=0){
            $row = $result->fetch_assoc(); // ["user_id","username","password"]
            $_SESSION['user_id'] = htmlspecialchars($row['user_id']);
            $_SESSION['username'] = htmlspecialchars($row["user_name"]);
            header("Location: authenticated.php");
        }
        else{
            echo "Username or Password is Wrong";
        }

    }
}

?>