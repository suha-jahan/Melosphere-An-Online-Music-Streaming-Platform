<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="index.php">Melosphere</a></h1>
        <nav>
          <ul>
            <li><a href="about.php">About Us</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
          </ul>
        </nav>
      </div>
    </header>
    <a ></a>

    <section class="main-content">
      <h2>Welcome to Melosphere!</h2>
      <p class="main-head">Listen to the latest hits completely free of charge!.</p>
    </section>
    <footer>
      <div class="container">
        <p>&copy; 2023 MusicProject. All rights reserved.</p>
      </div> 
    </footer>
  </body>
</html>
