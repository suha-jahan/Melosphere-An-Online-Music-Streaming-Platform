<?php
session_start();
require_once("DBconnect.php");
$all_songs = 'SELECT song_id, song_name, genre, album_name, artist_name, song_link, no_of_plays FROM song';
$result = mysqli_query($conn,$all_songs);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>"/>
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="authenticated.php">Melosphere</a></h1>
        <nav>
          <ul>
            <li><a href="song.php">Songs</a></li>
            <li><a href="playlist.php">My Playlist</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
            

          </ul>
        </nav>
      </div>
    </header>

    <section class="main-content">
      <p class="main-head">Delve into a plethora of genres and artists in our Songs Section!</p>
    </section>

    <div>
      <table class="table">
        <tr>
          <th id='play'>Play</th>
          <th id="song">Song</th>
          <th id="genre">Genre</th>
          <th id="Album">Album</th>
          <th id="Artist">Artist</th>
          <th id="No-of-plays">Number of Times Played</th>
        </tr>
      
      <?php

        while($row = mysqli_fetch_assoc($result)){
      ?>
      <tr>
          <td class="play">
          <form action="increment-play.php" method="post">
            <button type="submit" name="play" value="<?php echo htmlspecialchars($row["song_id"])?>">Play</button>
          </form>
          </td>
          <td>
            <?php echo htmlspecialchars($row["song_name"])?>
            <form action="add-to-favorite.php" method="post">
              <button class="link" type="submit" name="favorites" value="<?php echo htmlspecialchars($row["song_id"])?>">Favorite</button>
              </form>
        </td>
          <td><?php echo htmlspecialchars($row["genre"])?></td>
          <td>
            <form action="show-album-songs.php" method="post">
              <button class = "link" type="submit" name="album-song" value="<?php echo htmlspecialchars($row["album_name"])?>"><?php echo htmlspecialchars($row["album_name"])?></button>
            </form>
              


          </td>
          <td><?php echo htmlspecialchars($row["artist_name"])?></td>
          <td><?php echo htmlspecialchars($row["no_of_plays"])?></td>
      </tr>

      <?php
      
        }         
      ?>


      </table>
    </div>  
    <footer>
      <div class="container">
        <p>&copy; 2023 MusicProject. All rights reserved.</p>
      </div> 
    </footer>
  </body>
</html>

