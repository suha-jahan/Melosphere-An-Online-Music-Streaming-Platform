

<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Name Change Form</title>
  <link rel="stylesheet" href="register.css">
</head>
<body>
  <div class="register-container">


	<form action="update-name.php" class="name-change form" method="post">

		  <h2>Change Name</h2>

			  <label for="new_name">New Name:</label>
			  <input type="text" name="new_name" id="new_name" required>

			  <br>

			  <button type="submit" name="change_name">Change Name</button>

			  <br>
	</form>
  </div>	
</body>
</html>
  