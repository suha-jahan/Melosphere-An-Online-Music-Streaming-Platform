<?php


session_start();

// Include database connection
require_once("DBconnect.php");

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
  header("Location: login.php");
  
}

// Get user information
$user_id = $_SESSION["user_id"];
$sql = "SELECT * FROM user WHERE user_id=$user_id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Process form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Change name
  if (isset($_POST["change_name"])) {
    $new_name = trim($_POST["new_name"]);

    if (empty($new_name)) {
      $errors[] = "Please enter a new name.";
    } else {
      $update_name_sql = "UPDATE user SET user_name='$new_name' WHERE user_id=$user_id";
		}  

      if ($conn->query($update_name_sql)) {
        $user["name"] = $new_name;
        echo "Name Changed Successfully!";
        $_SESSION["username"] = $new_name;
        header("Location: authenticated.php");
      } else {
        $errors[] = "Error updating name: " . $conn->error;
      }
    }
  }
?>  