<?php
require_once('DBConnect.php');
if ($_SERVER["REQUEST_METHOD"] === "POST"){
    if(isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])){

        $name = $_POST['username'];
        $mail = $_POST['email'];
        $password = htmlspecialchars($_POST['password']);

        $sql = "INSERT INTO user (user_name, email, password) VALUES('$name','$mail','$password')";
        $result = mysqli_query($conn,$sql);

        if(mysqli_affected_rows($conn)){

            header("Location:login.php");

        }
        else{
            echo "Insertion Failed";
        }


    }
}

?>


    







