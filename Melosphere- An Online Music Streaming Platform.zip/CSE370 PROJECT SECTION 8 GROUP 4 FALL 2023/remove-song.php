<?php
require_once('DBconnect.php');
if ($_SERVER["REQUEST_METHOD"] === "POST"){
    if(isset($_POST['remove'])){
        $songID = $_POST['remove'];

        // Extracting song name to remove from album

        $songName_query = "SELECT song_name FROM song WHERE song_id = '$songID'";
        $execute_song_name_query = mysqli_query($conn,$songName_query);
        $songNameRow = mysqli_fetch_assoc($execute_song_name_query);
        $songName = $songNameRow['song_name'];
        $remove_from_album_query = "DELETE FROM track_of_album WHERE album_song = '$songName'";
        $run_query = mysqli_query($conn,$remove_from_album_query);


        // removing from song table
        $remove_query = "DELETE FROM song WHERE song_id = '$songID'";
        $run_query = mysqli_query($conn,$remove_query);

    


        header("Location:song-admin.php");

    }
}
?>