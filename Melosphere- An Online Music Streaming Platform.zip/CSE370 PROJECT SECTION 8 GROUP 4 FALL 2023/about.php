<!DOCTYPE html>
<html lang="en">
<form action="search.php" method="post">

<head>
    <meta charset="UTF-8" />
    <title>MusicProject - About Us</title>
    <link rel="stylesheet" href="aboutstyles.css" />
    <link rel="stylesheet" href="searchbar.css" />

</head>
<body>
    <header>
        <div class="container">
            <h1><a href="index.php">MusicProject</a></h1> 
            <nav>
                <ul>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="login.html">Login</a></li>
                    <li><a href="register.html">Register</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="about-content">
        <h2>About Us</h2>
        <?php
  
        echo "<p>Welcome to MusicProject – Your Free and Unlimited Music Experience!

        At MusicProject, we are passionate about bringing music to the fingertips of everyone, without any cost. Our Spotify clone offers a seamless and user-friendly platform for music enthusiasts to explore, discover, and enjoy a vast library of songs spanning various genres.</p>";
        ?>


        <form action="search.php" method="post">
            <div class="floating-search-bar">
                <input type="text" name="search" class="search-input" placeholder="Search songs...">
                <button type="submit" class="search-button">Search</button>
            </div>
        </form>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 MusicProject. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

