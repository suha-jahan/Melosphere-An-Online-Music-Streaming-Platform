<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Login Form</title>
    <link rel="stylesheet" href="login.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <header>
        <div class="container">
          <h1><a href="index.php">Melosphere</a></h1>
          <nav>
            <ul>
              <li><a href="about.php">About Us</a></li>
              <li><a href="login.php">Login</a></li>
              <li><a href="register.php">Register</a></li>
            </ul>
          </nav>
        </div>
      </header>
  
    <div class="login-container">
      <form action="signin.php"class="login-form" method="post">
        <h2>Login</h2>
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" required />
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required />
        </div>
        <input class="button" type="submit" value="Sign In">
      </form>
      <p id="not">Not Registered?</p>
      <a href="register.php" class="register">Register Here!</a>
    </div>
  </body>
</html>
