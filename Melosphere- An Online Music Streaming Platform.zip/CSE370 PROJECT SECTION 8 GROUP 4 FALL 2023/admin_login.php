<?php
session_start();
require_once('DBconnect.php');
if ($_SERVER["REQUEST_METHOD"] === "POST"){
    if(isset($_POST['username']) && isset($_POST['password'])){

        $username = htmlspecialchars($_POST['username']);
        $password = htmlspecialchars($_POST['password']);
        $sql = "SELECT * FROM user WHERE user_name='$username' AND password = '$password'";
        
        $result = mysqli_query($conn,$sql);

        if(mysqli_num_rows($result) !=0){
            $row = $result->fetch_assoc();
            $u = $row["user_name"];
            if($u == "admin"){

                $_SESSION["admin"] = $username;
                header("Location:adminView.php");
            }

            else{
                echo "Hah! Not an Admin!";
            }

            
        
        }
        else{
            echo "Username or Password is Wrong";
        }

    }
}

?>