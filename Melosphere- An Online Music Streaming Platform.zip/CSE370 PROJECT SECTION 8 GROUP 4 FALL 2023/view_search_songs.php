<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Search Songs</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>
    <div>
        <label for="search">Search Song: </label>
        <input type="text" id="search" name="search">
        <button onclick="searchSong()">Search</button>
    </div>

    <h2>Search Songs Table</h2>

    <?php
    include "DBConnect.php";

    $query = "SELECT song_id, song_name, artist_name FROM song";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "<table border='1'>";
        echo "<tr><th>Song ID</th><th>Song Name</th><th>Artist Name</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$row['song_id']}</td>";
            echo "<td>{$row['song_name']}</td>";
            echo "<td>{$row['artist_name']}</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "No songs found.";
    }

    $conn->close();
    ?>

    <script>
        function searchSong() {
            var searchValue = document.getElementById('search').value;

            $.ajax({
                type: 'POST',
                url: 'search.php',
                data: { search: searchValue },
                success: function(data) {

                    $('body').html(data);
                },
                error: function() {
                    console.log('Error in AJAX request.');
                }
            });
        }
    </script>
</body>
</html>

