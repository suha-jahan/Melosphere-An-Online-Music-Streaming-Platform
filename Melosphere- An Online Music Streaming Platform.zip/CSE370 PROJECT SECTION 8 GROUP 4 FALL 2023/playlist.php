<?php
session_start();

// Include database connection
require_once("DBconnect.php");

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

// Process form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create Playlist
    if (isset($_POST["create_playlist"])) {
        $playlist_name = trim($_POST["playlist_name"]);

        if (!empty($playlist_name)) {
            // Insert new playlist into the database
            $insert_playlist_sql = "INSERT INTO playlist (user_id, playlist_name) VALUES ($user_id, '$playlist_name')";
            $conn->query($insert_playlist_sql);
        }
    }

    // Add Song to Playlist
    if (isset($_POST["add_to_playlist"])) {
        $playlist_id = $_POST["playlist_id"];
        $song_id = $_POST["song_id"];

        // Insert song into the playlist
        $insert_song_sql = "INSERT INTO playlist_song (playlist_id, song_id) VALUES ($playlist_id, $song_id)";
        $conn->query($insert_song_sql);
    }
}

// Fetch user's playlists
$get_playlists_sql = "SELECT * FROM playlist WHERE user_id=$user_id";
$playlists_result = $conn->query($get_playlists_sql);
$playlists = $playlists_result->fetch_all(MYSQLI_ASSOC);

// Fetch available songs
$get_songs_sql = "SELECT * FROM songs";
$songs_result = $conn->query($get_songs_sql);
$songs = $songs_result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>
