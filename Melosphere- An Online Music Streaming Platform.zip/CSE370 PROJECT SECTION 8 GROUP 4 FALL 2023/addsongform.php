
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Registration Form</title>
  <link rel="stylesheet" href="register.css?v=<?php echo time(); ?>">
</head>
<body>
  <div class="register-container">
    <form action="addSong.php" class="register-form" method="post">
      <h2>Add a Song</h2>
      <div class="form-group">
        <label for="username">Song Name</label>
        <input type="text" id="song" name="song" required>
      </div>
      <div class="form-group">
        <label for="genre">Genre</label>
        <input type="text" id="genre" name="genre" required>
      </div>
      <div class="form-group">
        <label for="album">Album Name</label>
        <input type="text" id="album" name="album" required>
      </div>
      <div class="form-group">
        <label for="artist">Artist Name</label>
        <input type="text" id="artist" name="artist" required>
      </div>
      <div class="form-group">
        <label for="link">Song Link</label>
        <input type="text" id="link" name="link" required>
      </div>
      <button type="submit">Add</button>
    </form>
  </div>
</body>
</html>
