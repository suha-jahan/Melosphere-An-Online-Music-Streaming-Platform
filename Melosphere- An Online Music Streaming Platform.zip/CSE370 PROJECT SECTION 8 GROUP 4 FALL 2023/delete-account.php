<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete Account Form</title>
  <link rel="stylesheet" href="register.css">
</head>
<body>
  <div class="register-container">


	<form action="del.php" class="Delete account form" method="post">

		  <h2>Are you Sure you want to delete your account?</h2>
			
			  <button type="submit" name="answer" value="yes">Yes</button>
			  <button type="submit" name="answer" value="no">No</button>

			  

			  <br>
	</form>
  </div>	
</body>
</html>