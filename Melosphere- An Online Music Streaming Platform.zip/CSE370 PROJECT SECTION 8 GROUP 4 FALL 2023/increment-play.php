<?php
session_start();
require_once('DBConnect.php');
if ($_SERVER["REQUEST_METHOD"] === "POST"){
if(isset($_POST['play'])){

      $song_id = $_POST['play'];


      $sql_retrieve_plays = "SELECT no_of_plays FROM song WHERE song_id = '$song_id'";
      $sql_execute_retrieve = mysqli_query($conn,$sql_retrieve_plays);

      $no_of_plays_row = mysqli_fetch_assoc($sql_execute_retrieve);
      $no_of_plays = $no_of_plays_row['no_of_plays'];
      $no_of_plays += 1;
      $sql_update_plays = "UPDATE song SET no_of_plays = '$no_of_plays' WHERE song_id = '$song_id'";
      $sql_execute_update = mysqli_query($conn,$sql_update_plays);

      $sql_song_link = "SELECT song_link FROM song WHERE song_id = '$song_id'";
      $sql_execute_song_link = mysqli_query($conn,$sql_song_link);
      $song_link_row = mysqli_fetch_assoc($sql_execute_song_link);
      $song_link = $song_link_row['song_link'];

      $sql_retrieve_name = "SELECT song_name FROM song WHERE song_id = '$song_id'";
      $sql_execute_retrieve_name = mysqli_query($conn,$sql_retrieve_name);
      $name_row = mysqli_fetch_assoc($sql_execute_retrieve_name);
      $songName = $name_row['song_name'];
      
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="authenticated.php">Melosphere</a></h1>
        <nav>
          <ul>
            <li><a href="song.php">Songs</a></li>
            <li><a href="playlist.php">My Playlist</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
            <li><a href="favorite.php">Favorite</a></li>
            

          </ul>
        </nav>
      </div>
    </header>

    <section class="main-content">
      <p class="main-head">Now Playing: <?php echo htmlspecialchars($songName)?></p>
    </section>
    <div>
    <audio controls class="player" autoplay>
        <source src="<?php echo htmlspecialchars($song_link)?>" type="audio/ogg">
    </audio>
    <footer>
      <div class="container">
        <p>&copy; 2023 MusicProject. All rights reserved.</p>
      </div> 
    </footer>
  </body>
</html>






























