<?php


session_start();

// Include database connection
require_once("DBconnect.php");

// Change password
  if (isset($_POST["new_password"])) {
    $current_password = trim($_POST["previous_password"]);
    $new_password = trim($_POST["new_password"]);
    $confirm_password = trim($_POST["confirm_password"]);
    $user_id = $_SESSION['user_id'];
    $old_pwd_fetch_query = "SELECT password FROM user WHERE user_id='$user_id'";
    $run_query = mysqli_query($conn,$old_pwd_fetch_query);
    $old_pass_row = mysqli_fetch_assoc($run_query);
    $old_password = $old_pass_row["password"];
    if($old_password != $current_password){
      echo "Old Password is Incorrect";
      die();
    }

    
    if ($new_password != $confirm_password) {
      $errors[] = "New password and confirmation password do not match.";
	}else {
		
      

      $update_password_sql = "UPDATE user SET password='$new_password' WHERE user_id=$user_id";
	}  

    if ($conn->query($update_password_sql)) {
        $success = "Password changed successfully.";
		echo $success;
	}
      else {
        $errors[] = "Error updating password: " . $conn->error;
      }
    }
  
  
?>    