<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Successful Search</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>
    <div>
        <form action="search.php" method="post">
            <label for="search">Search Song: </label>
            <input type="text" id="search" name="search">
            <button type="submit">Search</button>
        </form>
    </div>

    <?php
    if (isset($_GET['song_name'])) {
        $songName = $_GET['song_name'];

        echo "<h1>Successful Search for $songName</h1>";

        echo "<audio controls>";
        echo "<source src='aud/$songName.mp3' type='audio/mp3'>";
        echo "</audio>";

        echo "<p><a href='view_search_songs.php'>View Search Songs</a></p>";
    } else {
        echo "<p>Invalid request.</p>";
    }
    ?>
</body>
</html>







