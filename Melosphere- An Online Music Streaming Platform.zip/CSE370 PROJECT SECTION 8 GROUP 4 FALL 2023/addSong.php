<?php
session_start();
require_once('DBConnect.php');
if ($_SERVER["REQUEST_METHOD"] === "POST"){
    if(isset($_POST['song']) && isset($_POST['genre']) && isset($_POST['album']) && isset($_POST['artist'])&& isset($_POST['link'])){

        $song = $_POST['song'];
        $genre= $_POST['genre'];
        $album = $_POST['album'];
        $artist = $_POST['artist'];
        $link = $_POST['link'];

        // First We Check if the artist is already in the artist table or not.

        $check_artist = "SELECT * FROM artist WHERE artist_name= '$artist'";
        $result_check_artist = mysqli_query($conn,$check_artist);

        $check_row_artist = mysqli_num_rows($result_check_artist);

        if($check_row_artist==0){

                $insert_artist = "INSERT INTO artist VALUES('$artist')";
                $run_insert_query = mysqli_query($conn,$insert_artist);
                

        }
        
        // Now We Check if the album is already in the album table or not.

        $check_album = "SELECT * FROM album where album_name = '$album'";
        $result_check_album = mysqli_query($conn,$check_album);

        $check_row_album = mysqli_num_rows($result_check_album);

        if($check_row_album==0){

                $insert_album = "INSERT INTO album VALUES('$album')";
                $run_insert_query = mysqli_query($conn,$insert_album);

        }


        # Now that the foreign keys are handled, we insert song into songs table

        $sql_song = "INSERT INTO song VALUES(NULL,'$song','$genre','$album','$artist','$link',0)";
        $sql_album_song = "INSERT INTO track_of_album VALUES ('$album','$song')";
        $result = mysqli_query($conn,$sql_song);
        $result = mysqli_query($conn,$sql_album_song);

        if(mysqli_affected_rows($conn)){

            header("Location:adminView.php");

        }
        else{
            echo "Insertion Failed";
        }


    }
}
?>


    







