<?php
session_start();
require_once("DBconnect.php");
$all_songs = 'SELECT song_id, song_name, Genre, Album_Name, Artist_Name, song_link FROM song';
$result = mysqli_query($conn,$all_songs);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>"/>
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="adminView.php">MusicProject</a></h1>
        <nav>
          <ul>
            <li><a href="song-admin.php">Songs</a></li>
            <li><a href="addsongform.php">Add Songs</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <section class="main-content">
      <h2>Remove Song</h2>
    </section>

    <div>
      <table class="table">
        <tr>
          <th id="song">Song</th>
          <th id="genre">Genre</th>
          <th id="Album">Album</th>
          <th id="Country">Artist</th>
          <th id='play'></th>
        </tr>
      
      <?php

        while($row = mysqli_fetch_assoc($result)){
      ?>

      <tr>
          <td>
          
          
          <?php echo $row["song_name"]?></td>
          <td><?php echo htmlspecialchars($row["Genre"])?></td>
          <td><?php echo htmlspecialchars($row["Album_Name"])?></td>
          <td><?php echo htmlspecialchars($row["Artist_Name"])?></td>
          <td class="play">
            <form action="remove-song.php" method="post">
                <?php $songID = htmlspecialchars($row["song_id"])?>
              <button class = "remove" type="submit" name="remove" value="<?php echo htmlspecialchars($songID)?>">Remove Song</button>
            </form>
          </td>
      </tr>

      <?php
      
        }         
      ?>


      </table>
    </div>  

  



    

  
    
  

    <footer>
      <div class="container">
        <p>&copy; 2023 MusicProject. All rights reserved.</p>
      </div> 
    </footer>
  </body>
</html>

