<?php
session_start();
require_once('DBConnect.php');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>MusicProject - Home</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <header>
      <div class="container">
        <h1><a href="authenticated.php">Melosphere</a></h1>
        <nav>
          <ul>
            <li><a href="search.php">Search</a></li>
            <li><a href="song.php">Songs</a></li>
            <li><a href="playlist.php">My Playlist</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
            <li><a href="favorite.php">Favorite</a></li>
            <li><a href="search.php">Search</a></li>
            

          </ul>
        </nav>
      </div>
    </header>

    <section class="main-content">
      <h2>Welcome <?php echo htmlspecialchars($_SESSION["username"])?>!</h2>
    </section>
    <footer>
      <div class="container">
        <p>&copy; 2023 MusicProject. All rights reserved.</p>
      </div> 
    </footer>
  </body>
</html>

