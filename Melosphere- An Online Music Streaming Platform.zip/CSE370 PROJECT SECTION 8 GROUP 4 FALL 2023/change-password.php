<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Name Change Form</title>
  <link rel="stylesheet" href="register.css">
</head>
<body>
  <div class="register-container">


	<form action="update-pass.php" class="password-change form" method="post">

		  <h2>Change Password</h2>
			<label for="previous_password">Previous Password:</label>
			  <input type="password" name="previous_password" id="previous_password" required>
			<label for="new_password">New Password:</label>  
			  <input type="password" name="new_password" id="new_password" required>
			<label for="confirm_password">Confirm Password:</label>  
			  <input type="password" name="confirm_password" id="confirm_password" required>

			  <br>

			  <button type="submit" >Enter New Password</button>

			  <br>
	</form>
  </div>	
</body>
</html>