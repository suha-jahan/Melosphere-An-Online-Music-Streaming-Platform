

<?php

session_start();
require_once("DBconnect.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST['answer'])) {
    $answer = $_POST['answer'];
    if ($answer === 'yes') {
      $user_id=$_SESSION["user_id"];
	  $delete_account_sql = "DELETE FROM user WHERE user_id=$user_id";
	  if ($conn->query($delete_account_sql)) {
        session_destroy();
        header("Location: index.php");
	  }
    }	  

      // Handle 'yes' option
    } elseif ($answer === 'no') {
      header("Location: settings.php");
      // Handle 'no' option
	}else {
      header("Location: settings.php");
    }
   
}else {
    echo "No answer received";
  }


session_destroy();
?>
