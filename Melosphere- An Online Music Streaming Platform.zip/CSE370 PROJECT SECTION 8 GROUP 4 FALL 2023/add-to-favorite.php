<?php
session_start();

// Include database connection
require_once("DBconnect.php");

if(isset($_POST['favorites'])){
	$song_id=$_POST['favorites'];
	$user_id = $_SESSION["user_id"];


	
	$sql_insert="INSERT INTO favorite VALUES ('$user_id','$song_id')";
	$sql_run=mysqli_query($conn,$sql_insert);
	header("location:favorite.php");


   
}



?>